﻿using Events.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Events.DataTemplateSelectors
{
    class EventTemplateSelector : DataTemplateSelector
    {
        public DataTemplate AllDayEventTemplate { get; set; }

        public DataTemplate OneSessionEventTemplate { get; set; }

        public DataTemplate TwoSessionEventTemplate { get; set; }


        protected override DataTemplate SelectTemplateCore(object item, DependencyObject container)
        {
            var selectedEvent = MainVM.Instance.EventVM.SelectedEvent;
            return selectedEvent.IsAllDayEvent ? AllDayEventTemplate : (selectedEvent.IsSecondSessionAvailable ? TwoSessionEventTemplate : OneSessionEventTemplate);
        }
    }
}
