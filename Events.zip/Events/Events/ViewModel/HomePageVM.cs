﻿using LightBuzz.SMTP;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Email;

namespace Events.ViewModel
{
    public class HomePageVM : BaseVM
    {
        private ObservableCollection<Event> myEvents;
        private ObservableCollection<Event> otherEvents;
        private ObservableCollection<Event> bookedEvents;
        private ObservableCollection<Event> home_MyEvents;
        private ObservableCollection<Event> home_OtherEvents;
        private ObservableCollection<Event> home_BookedEvents;
        private double amountDue;
        private bool isMoreVisible;
        private Session session1;
        private Session session2;

        public string WelcomeString
        {
            get
            {
                return string.Format("Welcome, {0}", MainVM.Instance.AuthVM.CurrentUser.FirstName);
            }
        }

        public Session Session1
        {
            get
            {
                return session1;
            }
            set
            {
                session1 = value;
                RaisePropertyChanged("Session1");
            }
        }

        public Session Session2
        {
            get
            {
                return session2;
            }
            set
            {
                session2 = value;
                RaisePropertyChanged("Session2");
            }
        }



        public ObservableCollection<Event> MyEvents
        {
            get
            {
                return myEvents ?? (myEvents = new ObservableCollection<Event>());
            }
        }

        public ObservableCollection<Event> OtherEvents
        {
            get
            {
                return otherEvents ?? (otherEvents = new ObservableCollection<Event>());
            }
        }

        public ObservableCollection<Event> BookedEvents
        {
            get
            {
                return bookedEvents ?? (bookedEvents = new ObservableCollection<Event>());
            }
        }

        #region Collection bind in homepage

        public ObservableCollection<Event> Home_MyEvents
        {
            get
            {
                return home_MyEvents ?? (home_MyEvents = new ObservableCollection<Event>());
            }
        }

        public ObservableCollection<Event> Home_OtherEvents
        {
            get
            {
                return home_OtherEvents ?? (home_OtherEvents = new ObservableCollection<Event>());
            }
        }

        public ObservableCollection<Event> Home_BookedEvents
        {
            get
            {
                return home_BookedEvents ?? (home_BookedEvents = new ObservableCollection<Event>());
            }
        }

        #endregion



        public bool IsMoreVisible
        {
            get
            {
                return isMoreVisible;
            }
            set
            {
                isMoreVisible = value;
                RaisePropertyChanged("IsMoreVisible");
            }
        }

        public bool IsPromoShown
        {
            get
            {
                return !string.IsNullOrEmpty(MainVM.Instance.EventVM.SelectedEvent.PromoCode);
            }
        }

        public bool HasItems
        {
            get
            {
                return BookedEvents.Any();
            }
        }

        public bool HasMyEventItems
        {
            get
            {
                return MyEvents.Any();
            }
        }

        public bool HasOtherEventItems
        {
            get
            {
                return OtherEvents.Any();
            }
        }


        public double AmountDue
        {
            get
            {
                return amountDue;
            }
            set
            {
                amountDue = value;
                RaisePropertyChanged("AmountDue");
            }
        }

        public void Initialize()
        {
            MainVM.Instance.IsActionInProgress = true;

            if (MainVM.Instance.EventVM.Events.Any())
            {
                MainVM.Instance.EventVM.Events.Clear();
            }
            var query = MainVM.Instance.Conn.Table<Event>();


            query = MainVM.Instance.Conn.Table<Event>();


            foreach (var item in query)
            {
                if (!MainVM.Instance.EventVM.Events.Contains(item))
                {
                    Event queriedEvent = new Event()
                    {
                        Id = item.Id,
                        CreatedBy = item.CreatedBy,
                        Date = item.Date,
                        Description = item.Description,
                        Venue = item.Venue,
                        Name = item.Name,
                        Price = item.Price,
                        PromoCode = item.PromoCode,
                        IsFreeEvent = item.IsFreeEvent,
                        IsAllDayEvent = item.IsAllDayEvent,
                        IsSecondSessionAvailable = item.IsSecondSessionAvailable,
                        SessionString = item.SessionString,
                        AllDayEventRemainingSeats = item.AllDayEventRemainingSeats,
                        AllDayEventTotalSeats = item.AllDayEventTotalSeats,
                        AllDayDuration = item.AllDayDuration
                    };

                    if (!queriedEvent.IsAllDayEvent)
                    {

                        var sessions = queriedEvent.SessionString.Split('#').Where(s => !string.IsNullOrEmpty(s));

                        queriedEvent.Sessions = new ObservableCollection<Session>();

                        foreach (var session in sessions)
                        {
                            var sessionParams = session.Split(',').ToList<string>();

                            Session sessionItem = new Session
                            {
                                StartTime = TimeSpan.Parse(sessionParams[0].Split('-')[1]),
                                EndTime = TimeSpan.Parse(sessionParams[1].Split('-')[1]),
                                TotalSeats = int.Parse(sessionParams[2].Split('-')[1]),
                                RemainingSeats = int.Parse(sessionParams[3].Split('-')[1]),
                                Duration = sessionParams[4].Split('-')[1]
                            };

                            queriedEvent.Sessions.Add(sessionItem);
                        }
                    }

                    MainVM.Instance.EventVM.Events.Add(queriedEvent);
                }
            }

            if (MyEvents.Any())
            {
                MyEvents.Clear();
            }

            var myEventCollection = MainVM.Instance.EventVM.Events.Where(s => s.CreatedBy.Equals(MainVM.Instance.AuthVM.CurrentUser.StudentId));

            foreach (var item in myEventCollection)
            {
                if (!MyEvents.Contains(item))
                {
                    MyEvents.Add(item);
                    //MyEvents.Add(item);
                    //MyEvents.Add(item);
                    //MyEvents.Add(item);
                }
            }

            if (Home_MyEvents.Any())
            {
                Home_MyEvents.Clear();
            }

            foreach (var item in MyEvents)
            {
                if (Home_MyEvents.Count < 6)
                {
                    Home_MyEvents.Add(item);
                }
            }



            if (OtherEvents.Any())
            {
                OtherEvents.Clear();
            }

            var allEventsCollection = MainVM.Instance.EventVM.Events.Where(s => !s.CreatedBy.Equals(MainVM.Instance.AuthVM.CurrentUser.StudentId));
            foreach (var item in allEventsCollection)
            {
                OtherEvents.Add(item);
                //OtherEvents.Add(item);
                //OtherEvents.Add(item);
                //OtherEvents.Add(item);
            }

            if (Home_OtherEvents.Any())
            {
                Home_OtherEvents.Clear();
            }


            foreach (var item in OtherEvents)
            {
                if (Home_OtherEvents.Count < 6)
                {
                    Home_OtherEvents.Add(item);
                }
            }



            IsMoreVisible = OtherEvents.Count > 6;

            if (IsMoreVisible)
            {
                Home_OtherEvents.Add(new Event()
                {
                    Name = "Show All >"
                });
            }

            if (BookedEvents.Any())
            {
                BookedEvents.Clear();
            }

            if (MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds != null)
            {
                var ids = MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds.Split(',');

                var eventIds = ids.Where(s => !s.ToString().Equals(""));

                foreach (var item in eventIds)
                {
                    int id = int.Parse(item);

                    foreach (var eventItem in MainVM.Instance.EventVM.Events)
                    {
                        if (eventItem.Id == id)
                        {
                            BookedEvents.Add(eventItem);
                            //BookedEvents.Add(eventItem);
                            //BookedEvents.Add(eventItem);
                            //BookedEvents.Add(eventItem);
                        }
                    }
                }

                if (Home_BookedEvents.Any())
                {
                    Home_BookedEvents.Clear();
                }

                foreach (var item in BookedEvents)
                {
                    if (Home_BookedEvents.Count < 6)
                    {
                        Home_BookedEvents.Add(item);
                    }
                }
            }

            RaisePropertyChanged("HasItems");
            RaisePropertyChanged("HasMyEventItems");
            RaisePropertyChanged("HasOtherEventItems");


            ///*
            //remove this code block after testing
            //*/
            //User existingconact = MainVM.Instance.Conn.Query<User>("select * from User where StudentId='" + MainVM.Instance.AuthVM.CurrentUser.StudentId + "'").FirstOrDefault();

            //existingconact.MyBookedEventIds = null;

            //try
            //{
            //    MainVM.Instance.Conn.Update(existingconact);
            //}
            //catch (Exception ex)
            //{

            //}

            MainVM.Instance.IsActionInProgress = false;


        }

        public void GetDiscount()
        {
            double discountPercent = 0.0;
            switch (MainVM.Instance.EventVM.SelectedEvent.PromoCode)
            {
                case "GET15":
                    discountPercent = 15;
                    break;
                case "GET25":
                    discountPercent = 25;
                    break;
                case "GET45":
                    discountPercent = 45;
                    break;
                case "GET50":
                    discountPercent = 50;
                    break;
            }
            AmountDue = AmountDue - (AmountDue * discountPercent / 100);
        }


        public void CalculatePrice()
        {
            var ticketprice = MainVM.Instance.EventVM.SelectedEvent.Price;
            int numberofppl = 0;
            if (MainVM.Instance.EventVM.SelectedEvent.IsAllDayEvent)
            {
                numberofppl = MainVM.Instance.EventVM.DropDownSelectedValue;
            }
            else
            {
                if (MainVM.Instance.EventVM.IsSecondSessionAvailable)
                {
                    if (MainVM.Instance.EventVM.IsSession1Selected)
                    {
                        numberofppl = MainVM.Instance.EventVM.DropDownSelectedValue_Session1;
                    }
                    else
                    {
                        numberofppl = MainVM.Instance.EventVM.DropDownSelectedValue_Session2;
                    }
                }
                else
                {
                    numberofppl = MainVM.Instance.EventVM.DropDownSelectedValue_Session1;
                }
            }

            AmountDue = ticketprice * numberofppl;

        }

        public async Task<int> AddBooking(Event bookedEvent, string emailID)
        {
            MainVM.Instance.IsActionInProgress = true;

            var query = MainVM.Instance.Conn.Table<User>();

            User existingconact = MainVM.Instance.Conn.Query<User>("select * from User where StudentId='" + MainVM.Instance.AuthVM.CurrentUser.StudentId + "'").FirstOrDefault();

            existingconact.MyBookedEventIds = existingconact.MyBookedEventIds + bookedEvent.Id + ",";

            if (bookedEvent.IsAllDayEvent)
            {
                // existingconact.BookedSession = "allday";
                //existingconact.SeatsReserved = existingconact.SeatsReserved + bookedEvent.Id + "-" + MainVM.Instance.EventVM.DropDownSelectedValue + ",";
            }
            if (bookedEvent.IsSecondSessionAvailable)
            {
                if (MainVM.Instance.EventVM.IsSession1Selected)
                {
                    //  existingconact.BookedSession = "session1";
                    //   existingconact.SeatsReserved = existingconact.SeatsReserved + bookedEvent.Id + "-" + MainVM.Instance.EventVM.DropDownSelectedValue_Session1 + ",";
                }
                else
                {
                    // existingconact.BookedSession = "session2";
                    // existingconact.SeatsReserved = existingconact.SeatsReserved + bookedEvent.Id + "-" + MainVM.Instance.EventVM.DropDownSelectedValue_Session2 + ",";
                }
            }


            try
            {
                MainVM.Instance.IsActionInProgress = true;

                MainVM.Instance.Conn.Update(existingconact);

                using (SmtpClient client = new SmtpClient("smtp.gmail.com", 587, false, "akhil.sivanandan07@gmail.com", "unniakhil14523600"))
                {
                    EmailMessage emailMessage = new EmailMessage();

                    emailMessage.To.Add(new EmailRecipient(emailID));
                    emailMessage.Subject = "Booking confirmation";
                    var dateDay = bookedEvent.Date.Date.Month + "/" + bookedEvent.Date.Date.Day + "/" + bookedEvent.Date.Date.Year + " , " + bookedEvent.Date.Date.DayOfWeek;

                    emailMessage.Body = "Booking confirmed for " + bookedEvent.Name + " at " + bookedEvent.Venue + ", date/day - " + dateDay + ". Enjoy the event :)";

                    SmtpResult smtpResult = await client.SendMailAsync(emailMessage);
                }

                BookedEvents.Add(bookedEvent);
                MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds = existingconact.MyBookedEventIds;

            }
            catch (Exception ex)
            {
                MainVM.Instance.IsActionInProgress = false;

                return 0;
            }

            query = MainVM.Instance.Conn.Table<User>();

            MainVM.Instance.IsActionInProgress = false;

            return 1;
        }
    }
}
