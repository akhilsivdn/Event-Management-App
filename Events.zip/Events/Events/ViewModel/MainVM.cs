﻿using SQLite.Net.Attributes;
using System;
using System.IO;

namespace Events.ViewModel
{



    public class MainVM : BaseVM
    {
        private static MainVM _instance;

        string path;
        private SQLite.Net.SQLiteConnection conn;

        private AuthenticationVM authVM;
        private EventVM eventVM;
        private HomePageVM homeVM;
        private bool isActionInProgress;

        public MainVM()
        {

        }

        public SQLite.Net.SQLiteConnection Conn
        {
            get
            {
                if (conn == null)
                {
                    Initialize();
                }
                return conn;
            }
        }


        public static MainVM Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MainVM();
                }
                return _instance;
            }
        }

        public bool IsActionInProgress
        {
            get
            {
                return isActionInProgress;
            }
            set
            {
                isActionInProgress = value;
                RaisePropertyChanged("IsActionInProgress");
            }
        }


        public AuthenticationVM AuthVM
        {
            get
            {
                return authVM ?? (authVM = new AuthenticationVM());
            }
        }

        public HomePageVM HomeVM
        {
            get
            {
                return homeVM ?? (homeVM = new HomePageVM());
            }
        }

        public EventVM EventVM
        {
            get
            {
                return eventVM ?? (eventVM = new EventVM());
            }
        }

        public void Initialize()
        {
            path = Path.Combine(Windows.Storage.ApplicationData.Current.LocalFolder.Path, "db.sqlite");
            conn = new SQLite.Net.SQLiteConnection(new
               SQLite.Net.Platform.WinRT.SQLitePlatformWinRT(), path);



            try

            {
                //conn.DropTable<User>();
                //conn.DropTable<Event>();
            }
            catch (Exception ex)
            {

            }


            conn.CreateTable<User>();
            conn.CreateTable<Event>();
        }
    }
}
