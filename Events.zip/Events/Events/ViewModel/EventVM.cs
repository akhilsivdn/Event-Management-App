﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;

namespace Events.ViewModel
{
    public class EventVM : BaseVM
    {
        private ObservableCollection<Event> events;
        private Event selectedEvent;
        private bool isFreeEvent = true;
        private int reservedSeats;
        private Session session1;
        private Session session2;
        private bool isSecondSessionAvailable;
        private bool isAllDayEvent = true;
        private bool isPromoCodeAvaialble;
        private ObservableCollection<int> session1RemainingSeats;
        private ObservableCollection<int> session2RemainingSeats;
        private ObservableCollection<int> remainingSeats;
        private int dropValue;
        private int dropValue_Session1;
        private int dropValue_Session2;
        private bool isSession1Selected;
        private bool isSession2Selected;

        public Event SelectedEvent
        {
            get
            {
                return selectedEvent;
            }
            set
            {
                selectedEvent = value;
                RaisePropertyChanged("SelectedEvent");
            }
        }

        public Session Session1
        {
            get
            {
                return session1;
            }
            set
            {
                session1 = value;
                RaisePropertyChanged("Session1");
            }
        }

        public Session Session2
        {
            get
            {
                return session2;
            }
            set
            {
                session2 = value;
                RaisePropertyChanged("Session2");
            }
        }

        public bool IsFreeEvent
        {
            get
            {
                return isFreeEvent;
            }
            set
            {
                isFreeEvent = value;
                if (value)
                {
                    SelectedEvent.Price = 0.0;
                }
                RaisePropertyChanged("IsFreeEvent");
                RaisePropertyChanged("EnablePrice");
            }
        }

        public int ReservedSeats
        {
            get
            {
                return reservedSeats;
            }
            set
            {
                reservedSeats = value;
                RaisePropertyChanged("ReservedSeats");
            }
        }


        public bool EnablePrice
        {
            get
            {
                return !isFreeEvent;
            }
        }

        public bool IsSecondSessionAvailable
        {
            get
            {
                return isSecondSessionAvailable;
            }
            set
            {
                isSecondSessionAvailable = value;
                if (!value)
                {
                    IsSession1Selected = true;
                }
                RaisePropertyChanged("IsSecondSessionAvailable");
            }
        }

        public bool IsAllDayEvent
        {
            get
            {
                return isAllDayEvent;
            }
            set
            {
                isAllDayEvent = value;
                RaisePropertyChanged("IsAllDayEvent");
            }
        }

        public bool IsPromoCodeAvaialble
        {
            get
            {
                return isPromoCodeAvaialble;
            }
            set
            {
                isPromoCodeAvaialble = value;
                RaisePropertyChanged("IsPromoCodeAvaialble");
            }
        }

        public ObservableCollection<int> Session1RemainingSeats
        {
            get
            {
                return session1RemainingSeats ?? (session1RemainingSeats = new ObservableCollection<int>());
            }
        }

        public ObservableCollection<int> Session2RemainingSeats
        {
            get
            {
                return session2RemainingSeats ?? (session2RemainingSeats = new ObservableCollection<int>());
            }
        }

        public ObservableCollection<int> RemainingSeats
        {
            get
            {
                return remainingSeats ?? (remainingSeats = new ObservableCollection<int>());
            }
        }

        public int DropDownSelectedValue
        {
            get
            {
                return dropValue;
            }
            set
            {
                dropValue = value;
                RaisePropertyChanged("DropDownSelectedValue");
            }
        }

        public int DropDownSelectedValue_Session1
        {
            get
            {
                return dropValue_Session1;
            }
            set
            {
                dropValue_Session1 = value;
                RaisePropertyChanged("DropDownSelectedValue_Session1");
            }
        }

        public int DropDownSelectedValue_Session2
        {
            get
            {
                return dropValue_Session2;
            }
            set
            {
                dropValue_Session2 = value;
                RaisePropertyChanged("DropDownSelectedValue_Session2");
            }
        }

        public bool IsSession1Selected
        {
            get
            {
                return isSession1Selected;
            }
            set
            {
                isSession1Selected = value;
                RaisePropertyChanged("IsSession1Selected");
            }
        }

        public bool IsSession2Selected
        {
            get
            {
                return isSession2Selected;
            }
            set
            {
                isSession2Selected = value;
                RaisePropertyChanged("IsSession2Selected");
            }
        }

        public bool HasPromoCode
        {
            get
            {
                return !(string.IsNullOrEmpty(SelectedEvent.PromoCode));
            }
        }

        public ObservableCollection<Event> Events
        {
            get
            {
                return events ?? (events = new ObservableCollection<Event>());
            }
        }


        public string BookedEventName
        {
            get
            {
                return SelectedEvent.Name;
            }
        }

        public string BookedEventDescription
        {
            get
            {
                return SelectedEvent.Description;
            }
        }

        public string BookedEventVenue
        {
            get
            {
                return SelectedEvent.Venue;
            }
        }



        public bool HasRemainingSeats
        {
            get
            {
                if (SelectedEvent.IsAllDayEvent)
                {
                    return SelectedEvent.AllDayEventRemainingSeats > 0;
                }
                else
                {
                    return SelectedEvent.Sessions.Any() && SelectedEvent.Sessions[0]?.RemainingSeats > 0 || SelectedEvent.Sessions[1]?.RemainingSeats > 0;
                }
            }
        }


        public int InsertEvent(bool isInsert = true)
        {

            if (!string.IsNullOrEmpty(SelectedEvent.Name) && !string.IsNullOrEmpty(SelectedEvent.Description) &&
                !string.IsNullOrEmpty(SelectedEvent.Venue) && ((IsAllDayEvent && SelectedEvent.AllDayEventTotalSeats > 0) || (Session1.TotalSeats > 0 &&
                Session1.EndTime > Session1.StartTime) || (IsSecondSessionAvailable && Session2.TotalSeats > 0 &&
                Session2.EndTime > Session2.StartTime)))
            {
                MainVM.Instance.IsActionInProgress = true;

                try
                {
                    SelectedEvent.SessionString = string.Empty;

                    SelectedEvent.IsFreeEvent = IsFreeEvent;
                    SelectedEvent.CreatedBy = MainVM.Instance.AuthVM.CurrentUser.StudentId;
                    SelectedEvent.IsAllDayEvent = IsAllDayEvent;


                    if (!SelectedEvent.IsAllDayEvent)
                    {
                        TimeSpan diffTime = (Session1.EndTime - Session1.StartTime);
                        Session1.Duration = (diffTime.TotalMinutes > 59) ? string.Format("{0} hours.", diffTime.TotalHours) :
                               string.Format("{0} minutes.", diffTime.TotalMinutes);

                        if (IsSecondSessionAvailable)
                        {
                            TimeSpan diffTime_2 = (Session2.EndTime - Session2.StartTime);
                            Session2.Duration = (diffTime_2.TotalMinutes > 59) ? string.Format("{0} hours.", diffTime_2.TotalHours) :
                                string.Format("{0} minutes.", diffTime_2.TotalMinutes);
                        }

                        Session1.RemainingSeats = Session1.TotalSeats;

                        if (IsSecondSessionAvailable)
                        {
                            Session2.RemainingSeats = Session2.TotalSeats;
                        }

                        var session1String = "start-" + Session1.StartTime + ",end-" + Session1.EndTime + ",tseats-" + Session1.TotalSeats + ",rseats-" + Session1.RemainingSeats + ",duration-" + Session1.Duration + "#";
                        var session2String = string.Empty;


                        if (IsSecondSessionAvailable)
                        {
                            session2String = "start-" + Session2.StartTime + ",end-" + Session2.EndTime + ",tseats-" + Session2.TotalSeats + ",rseats-" + Session2.RemainingSeats + ",duration-" + Session2.Duration + "#";
                        }

                        SelectedEvent.SessionString = string.IsNullOrEmpty(session2String) ? session1String : session1String + session2String;

                    }

                    if (SelectedEvent.IsAllDayEvent)
                    {
                        SelectedEvent.AllDayDuration = "All Day (09.00 - 17.00 AEST)";
                    }

                    SelectedEvent.AllDayEventRemainingSeats = SelectedEvent.AllDayEventTotalSeats;

                    SelectedEvent.IsSecondSessionAvailable = IsSecondSessionAvailable;


                    if (isInsert)
                    {
                        MainVM.Instance.Conn.Insert(SelectedEvent);
                    }
                    else
                    {
                        MainVM.Instance.Conn.Update(SelectedEvent);
                    }

                    MainVM.Instance.IsActionInProgress = false;

                    return 1;
                }
                catch (Exception ex)
                {
                    MainVM.Instance.IsActionInProgress = false;
                    return 0;
                }
            }
            return 0;
        }

        public void PopulateDropDown()
        {
            Session1RemainingSeats?.Clear();
            Session2RemainingSeats?.Clear();
            RemainingSeats?.Clear();


            if (SelectedEvent.IsAllDayEvent)
            {
                for (int i = 0; i < SelectedEvent.AllDayEventRemainingSeats; i++)
                {
                    RemainingSeats.Add(i + 1);
                }
                DropDownSelectedValue = RemainingSeats.FirstOrDefault();
            }

            else
            {
                for (int i = 0; i < Session1.RemainingSeats; i++)
                {
                    Session1RemainingSeats.Add(i + 1);
                }
                DropDownSelectedValue_Session1 = Session1RemainingSeats.FirstOrDefault();

                if (SelectedEvent.IsSecondSessionAvailable)
                {
                    for (int i = 0; i < Session2.RemainingSeats; i++)
                    {
                        Session2RemainingSeats.Add(i + 1);
                    }
                    DropDownSelectedValue_Session2 = Session2RemainingSeats.FirstOrDefault();
                }
            }
        }



        public void GetReservedeatsCount()
        {
            if (MainVM.Instance.AuthVM.CurrentUser.SeatsReserved != null)
            {
                var ids = MainVM.Instance.AuthVM.CurrentUser.SeatsReserved.Split(',');

                var tuples = ids.Where(s => !s.ToString().Equals(""));


                foreach (var item in tuples)
                {
                    ids = item.Split('-');
                    if (int.Parse(ids[0]).Equals(MainVM.Instance.EventVM.SelectedEvent.Id))
                    {
                        ReservedSeats = int.Parse(ids[1]);
                        break;
                    }
                }

            }
        }

        public int UpdateEvent()
        {
            var query = MainVM.Instance.Conn.Table<Event>();
            query = MainVM.Instance.Conn.Table<Event>();
            int a = InsertEvent(false);
            query = MainVM.Instance.Conn.Table<Event>();
            return 1;
        }

        public int DeleteBooking()
        {
            MainVM.Instance.IsActionInProgress = true;

            var eventIDs = MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds.Split(',').Where(s => !s.ToString().Equals(""));

            foreach (var item in eventIDs)
            {
                if (int.Parse(item).Equals(SelectedEvent.Id))
                {
                    var removeString = item + ",";
                    var str = MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds.Replace(removeString, "");
                    MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds = str;

                    User existingconact = MainVM.Instance.Conn.Query<User>("select * from User where StudentId='" + MainVM.Instance.AuthVM.CurrentUser.StudentId + "'").FirstOrDefault();

                    existingconact.MyBookedEventIds = MainVM.Instance.AuthVM.CurrentUser.MyBookedEventIds;

                    try
                    {
                        MainVM.Instance.Conn.Update(existingconact);
                    }
                    catch (Exception ex)
                    {
                        MainVM.Instance.IsActionInProgress = false;
                        return 0;
                    }
                }
            }

            MainVM.Instance.IsActionInProgress = false;
            return 0;
        }
    }


    public class Session
    {
        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        public int TotalSeats { get; set; }

        public int RemainingSeats { get; set; }

        public string Duration { get; set; }

    }


    public class Event
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string Name { get; set; }

        public DateTimeOffset Date { get; set; }

        public string Venue { get; set; }

        public bool IsAllDayEvent { get; set; }

        public string PromoCode { get; set; }

        public double Price { get; set; }

        public bool IsFreeEvent { get; set; }

        public string Description { get; set; }

        public string AllDayDuration { get; set; }

        public string CreatedBy { get; set; }

        public string SessionString { get; set; }

        public bool IsSecondSessionAvailable { get; set; }

        public int AllDayEventTotalSeats { get; set; }

        public int AllDayEventRemainingSeats { get; set; }

        [Ignore]
        public ObservableCollection<Session> Sessions { get; set; }
    }
}
