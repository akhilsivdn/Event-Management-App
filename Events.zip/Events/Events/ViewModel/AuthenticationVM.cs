﻿using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using SQLiteNetExtensions.Extensions.TextBlob;
using SQLitePCL;
using SQLite.Net;
using Newtonsoft.Json;
using SQLite.Net.Attributes;
using System.Text.RegularExpressions;

namespace Events.ViewModel
{
    public class AuthenticationVM : BaseVM
    {
        private ObservableCollection<User> users;
        private User currentUser;
        private bool invalidFirstName;
        private bool invalidLastName;
        private bool invalidEmailID;
        private bool invalidStudentID;
        private bool invalidPassword;
        private bool isPasswordMismatch;

        public User CurrentUser
        {
            get
            {
                return currentUser ?? (currentUser = new User());
            }
            set
            {
                currentUser = value;
                RaisePropertyChanged("CurrentUser");
            }
        }


        public bool InvalidFirstName
        {
            get
            {
                return invalidFirstName;
            }
            set
            {
                invalidFirstName = value;
                RaisePropertyChanged("InvalidFirstName");
            }
        }

        public bool InvalidLastName
        {
            get
            {
                return invalidLastName;
            }
            set
            {
                invalidLastName = value;
                RaisePropertyChanged("InvalidLastName");
            }
        }

        public bool InvalidEmailID
        {
            get
            {
                return invalidEmailID;
            }
            set
            {
                invalidEmailID = value;
                RaisePropertyChanged("InvalidEmailID");
            }
        }

        public bool InvalidStudentID
        {
            get
            {
                return invalidStudentID;
            }
            set
            {
                invalidStudentID = value;
                RaisePropertyChanged("InvalidStudentID");
            }
        }

        public bool InvalidPassword
        {
            get
            {
                return invalidPassword;
            }
            set
            {
                invalidPassword = value;
                RaisePropertyChanged("InvalidPassword");
            }
        }

        public bool IsPasswordMismatch
        {
            get
            {
                return isPasswordMismatch;
            }
            set
            {
                isPasswordMismatch = value;
                RaisePropertyChanged("IsPasswordMismatch");
            }
        }

        public ObservableCollection<User> Users
        {
            get
            {
                return users ?? (users = new ObservableCollection<User>());
            }
        }




        public void InsertUser()
        {
            var regex = new Regex(@"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
            InvalidFirstName = string.IsNullOrEmpty(CurrentUser.FirstName);
            InvalidLastName = string.IsNullOrEmpty(CurrentUser.LastName);
            InvalidEmailID = string.IsNullOrEmpty(CurrentUser.EmailId) || !regex.IsMatch(CurrentUser.EmailId);
            InvalidPassword = string.IsNullOrEmpty(CurrentUser.Password);
            InvalidStudentID = string.IsNullOrEmpty(CurrentUser.StudentId) || CurrentUser.StudentId.Length != 7;


            if (!(InvalidFirstName || InvalidLastName || InvalidEmailID || InvalidFirstName || InvalidPassword || InvalidStudentID || IsPasswordMismatch))
            {
                try
                {
                    var s = MainVM.Instance.Conn.Insert(CurrentUser);
                    var query = MainVM.Instance.Conn.Table<User>();
                }
                catch (Exception ex)
                {

                }

            }
        }

        public void ResetFields()
        {
            CurrentUser = new User();
            InvalidFirstName = InvalidLastName = InvalidEmailID = InvalidPassword = InvalidStudentID = IsPasswordMismatch = false;
        }
    }

    public class User
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }

        public string StudentId { get; set; }
        public string Password { get; set; }

        public string SeatsReserved { get; set; }
        public string MyBookedEventIds { get; set; }

        public string BookedSession { get; set; }

    }
}
